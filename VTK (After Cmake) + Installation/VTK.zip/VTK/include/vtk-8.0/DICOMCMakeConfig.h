
#ifndef __DICOMCMakeConfig_h_
#define __DICOMCMakeConfig_h_

#define DICOM_DLL
/* #undef DICOM_STATIC */
#define DICOM_ANSI_STDLIB

#include <vtksys/Configure.hxx>

#endif
